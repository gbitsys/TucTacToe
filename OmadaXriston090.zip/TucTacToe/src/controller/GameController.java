package controller;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import model.GameModel;
import model.PlayersCatalogue;
import view.MainAreaPanel;
import view.MainWindow;
import view.BoardCell;


public class GameController extends WindowAdapter {
	MainWindow view;
	GameModel model;
	PlayersCatalogue playersCatalogue;
	
	public GameController() {		
		
	}
	
	@Override
	public void windowClosing(WindowEvent event) {
		quit();
	}
	
	
	public void start() {
		this.playersCatalogue = new PlayersCatalogue(this);
		this.view= new MainWindow(this);
		this.model = new GameModel(this);
		this.view.addWindowListener(this);
		this.view.setVisible(true);
		//this.playersCatalogue.loadPlayers();
	}
	
	public void quit() {		
		PlayersCatalogue.storePlayers();
		System.out.println("bye bye...");		
		System.exit(0);
	}	
	
	public void selectPlayer(String p, int pos) {
		this.model.selectPlayer(p, pos);
		System.out.println("Player " + pos + " set to " + p);
		this.view.getTopPanel().getStartGameBtn().setEnabled(model.ready());
	}
	
	public void startGame() {
		this.model.startGame();
		this.view.getTopPanel().getStartGameBtn().setEnabled(false);
		this.view.getTopPanel().getDeletePlayerBtn().setEnabled(false);
		this.view.getMainPanel().showCard("gb");
		this.view.getLeftPnl().getSelectPlayerBtn().setEnabled(model.noPlay());
		this.view.getRightPnl().getSelectPlayerBtn().setEnabled(model.noPlay());
		
	}
	
	public GameModel getModel() {
		return model;
	}
	
	public MainWindow getView() {
		return view;
	}
	
	public void inPlay() {
		view.getTopPanel().changeColorInGame();
	}
	
	public void noPlay() {
		view.getTopPanel().changeColorNoGame();
	}
	
	//if a player wins 
	public void winCase() {
		BoardCell[][] cells;
		view.getTopPanel().getDoneBtn().setEnabled(true);
		//repaint the cell
		cells = view.getMainPanel().getBoard().getCells();
		cells[model.getLastRow()][model.getLastCol()].repaint();
		
		view.getMainPanel().showResultDialog(model.getPlayersResult());
		//if someone presses done button hall of fame must be shown
		model.setFlagPlay(false);
		view.getTopPanel().doneBtnFunc();
	}
	
	//if a game is tie
	public void fullCase() {
		BoardCell[][] cells;
		this.view.getTopPanel().getDoneBtn().setEnabled(true);
		//repaint the cell
		cells = view.getMainPanel().getBoard().getCells();
		cells[model.getLastRow()][model.getLastCol()].repaint();
		
		view.getMainPanel().showResultDialog(model.getPlayersResult());
		//if someone presses done button hall of fame must be shown
		model.setFlagPlay(false);
		view.getTopPanel().doneBtnFunc();
	}
}

