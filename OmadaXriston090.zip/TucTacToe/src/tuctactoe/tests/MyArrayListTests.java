package tuctactoe.tests;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import util.MyArrayList;

public class MyArrayListTests {
	
	@Test
	@DisplayName("Test for returning. Also tests the add method")
	public void getTest() {
		MyArrayList <String>arr = new MyArrayList<String>();
		
		arr.add("Test");
		
		assertEquals("Test", arr.get(0));
		
		
	}
	
}
