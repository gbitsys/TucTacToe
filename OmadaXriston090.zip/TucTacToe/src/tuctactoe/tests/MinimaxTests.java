package tuctactoe.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import util.Minimax;
import util.Minimax.Move;

class MinimaxTests {

	@Test
	@DisplayName("Test if the evaluation of the board works correctly.")
	void evaluationTest() {
		char[][] board =  { {'O','X','X'},
							{'O',' ',' '},
							{' ',' ',' '}};
		
		assertEquals(0, Minimax.evaluate(board));
		
		
	}
	
	@Test 
	@DisplayName("Test the minimax algorithm")
	void testMinimax() {
		char[][] board =  { {'O','X','X'},
							{'X','O','O'},
							{'X','O','X'}};
		
		assertEquals(0, Minimax.minimax(board, 4, true));
	}
	
	@Test
	@Disabled
	@DisplayName("Test for finding the best move.")
	void testFindBestMove() {
		char[][] board =  { {'X','O','X'},
							{'O','O','X'},
							{' ',' ',' '}};
		
		Move move = new Move();
		move.row = 2;
		move.col = 1;
		
		assertEquals(move, Minimax.findBestMove(board, true));
	}
}
