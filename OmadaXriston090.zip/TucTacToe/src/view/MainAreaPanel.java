package view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

import controller.GameController;

public class MainAreaPanel extends GamePanel{
	CardLayout cards;
	GameBoard gameBoard;
	HallOfFame hof;
	FiveRecentGames fiveRecent;
	TopGames topGames;
	
	public MainAreaPanel(GameController gc) {
		super(gc);
		cards = new CardLayout();
		this.setLayout(cards);
		this.setBorder(new LineBorder(Color.GRAY, 1));
		this.setPreferredSize(new Dimension(MainWindow.WIDTH - 2*MainWindow.PLAYER_WIDTH, MainWindow.HEIGHT - MainWindow.TOP_HEIGHT));
		
		//creating instances of cards 
		hof = new HallOfFame(gc);
		this.add("hof", hof);
		
		gameBoard = new GameBoard(gc);
		this.add("gb", gameBoard);
		
		fiveRecent = new FiveRecentGames(gc);
		this.add("5r", fiveRecent);
		
		topGames = new TopGames(gc);
		this.add("top5", topGames);
		
	}
	public TopGames getTopGames() {
		return topGames;
	}
	
	public FiveRecentGames getFiveRecent() {
		return fiveRecent;
	}

	public GameBoard getBoard() {
		return gameBoard;
	}

	public void showCard(String s) {
		cards.show(this, s);
	}
	
	//Done button result
	public void showResultDialog(int pos) {
		if (pos == 0)
			JOptionPane.showMessageDialog(this, "[WIN] Player 0: "+gc.getView().getLeftPnl().currentPlayer+" with mark 'X'");
		if (pos == 1)
			JOptionPane.showMessageDialog(this, "[WIN] Player 1: "+gc.getView().getRightPnl().currentPlayer+" with mark 'O'");
		if (pos == -1)
			JOptionPane.showMessageDialog(this, "[TIE]");
	}

	public void showNameError(int caseError) {
		switch (caseError) {
		case 0:
			JOptionPane.showMessageDialog(this, "Player name too long (20 characters max)!");
			break;
		case 1:
			JOptionPane.showMessageDialog(this, "Player name already exists");
			break;
		}
	}

	public HallOfFame getHof() {
		return hof;
	}
}
