package view;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.border.LineBorder;
//prints the actual grid
import controller.GameController;
import model.GameModel;
//class becomes an "action listener"
@SuppressWarnings("serial")
public class BoardCell extends GamePanel implements MouseListener {
	public final static int CELL_PADDING = 10; //space between cells
	private int row, col; //these variables help us to transfer info about a cell in the game model 
	private boolean highlighted; //if a cell is clickable an mouse enters in it then it should be true
	
	public BoardCell(GameController gc, int row, int col) {
		super(gc);
		this.setBackground(Color.WHITE);
		this.row = row;
		this.col = col;
		this.addMouseListener(this);//adding a listener so the class can hear its own events
		this.highlighted = false;
		this.setLayout(null);
		timer.setRepeats(false);
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		//System.out.println("Mouse entered cell " + this);
		this.highlighted = true;
		repaint(); //to paint the component again
	}

	@Override
	public void mouseExited(MouseEvent e) {
		//System.out.println("Mouse exited on cell " + this);
		this.highlighted=false;
		repaint();//to paint the component again
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		//this.setBorder(new LineBorder(Color.DARK_GRAY, 1));
		char mark = getModel().getBoardMark(this.row, this.col);
		Graphics2D g2d = (Graphics2D) g;
		int size = this.getSize().width - 2 * CELL_PADDING;
		g2d.setStroke(new BasicStroke(6));
		if (mark == ' ') {
			if (highlighted) {
				g2d.setColor(Color.LIGHT_GRAY);
				g2d.fillRect(CELL_PADDING, CELL_PADDING, size, size);
			}
			return;
		} else if (mark == 'X') {
			g2d.drawLine(CELL_PADDING, CELL_PADDING, CELL_PADDING + size, CELL_PADDING + size);
			g2d.drawLine(CELL_PADDING + size, CELL_PADDING, CELL_PADDING, CELL_PADDING + size);
		} else if (mark == 'O'){
			g2d.drawOval(CELL_PADDING, CELL_PADDING, size, size);
		}
	}
	
	@Override
	public String toString() {
		return "(" + this.row + "," + this.col + ")";
	}

	//here is the input for our model
	@Override
	public void mouseClicked(MouseEvent e) {
		//if ai plays we don't want user to interrupt
		if ((getModel().isMoverX() && getModel().getPlayersObj()[0].isAi()) || (!getModel().isMoverX() && getModel().getPlayersObj()[1].isAi()))
			return;
		//System.out.println("Mouse clicked on cell " + this);
		if (getModel().inPlay()) {
			this.lastMove(row, col); //we should repaint the mark component
			getModel().makeMove(row, col);
			repaint();//to paint the component again
		}
	}
	
	Timer timer = new Timer(1000, (event)->{
		if (getModel().inPlay()) {
			this.lastMove(row, col); //we should repaint the mark component
			getModel().makeMove(row, col);
			repaint();//to paint the component again
		}
	});
	
	

	/*This method is called only if a player is AI.*/
	public void makeMoveAI() {
		timer.restart();
	}
	
	//we want to get the last cell played
	public void lastMove(int row, int col) {
		int[] point = new int[2];
		point[0]=row;
		point[1]=col;
		getModel().setLastPoint(point);
	}
	
	//we need these just to not have an implementation error 
	@Override
	public void mousePressed(MouseEvent e) {
	}
	@Override
	public void mouseReleased(MouseEvent e) {
	}
	
	
	//in case we want to get this particular cell
	public BoardCell getCell(int row, int col) {
		if (row==this.row && col==this.col) 
			return this;
		
		return null;
	}
}
