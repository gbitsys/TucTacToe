package view;

import javax.swing.JPanel;

import controller.GameController;
import model.GameModel;

/*
 * all panels are subclasses of this one 
 * 
 */
public abstract class GamePanel extends JPanel{
	GameController gc;
	
	public GamePanel(GameController gc) {
		this.gc=gc;
	}

	public GameController getGameController() {
		return gc;
	}
	
	public GameModel getModel() {
		return gc.getModel();
	}
}
