package view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.GameController;
import model.GameRecord;
import model.Player;

public class FiveRecentGames extends GamePanel{
	JTextArea txtAreaGames;
	JButton backBtn; //gets us to hall of fame
	String plName;

	public FiveRecentGames(GameController gc) {
		super(gc);
		backBtn = new JButton("Back");
		backBtn.setPreferredSize(new Dimension(100, 40));
		backBtn.setEnabled(true);
		this.add(backBtn);
		backBtn.addActionListener(e -> {
			gc.getView().getMainPanel().showCard("hof");
		});
		
		txtAreaGames = new JTextArea(10,10);		
		txtAreaGames.setPreferredSize(new Dimension(MainWindow.WIDTH - 2 * MainWindow.PLAYER_WIDTH, MainWindow.HEIGHT - MainWindow.TOP_HEIGHT));
		txtAreaGames.setAlignmentX(CENTER_ALIGNMENT);
		Font font = new Font("SansSerif", Font.BOLD,15);
		txtAreaGames.setFont(font);
		txtAreaGames.setEnabled(false);		
		txtAreaGames.setMargin(new Insets(10, 10, 10, 10));
		//txtAreaGames.setText(getRecentGames(plName));
		
		add(txtAreaGames);
		
		
	}
	
	public String getRecentGames(String name) {
		System.out.println("[DEBUG]Entered getRecentGames");
		StringBuilder sb = new StringBuilder("");
		Player pl = new Player(name);
		pl = gc.getModel().getPlayerCatalogue().getPlayerByName(name);
		GameRecord[] rg = new GameRecord[5];
		rg = pl.findRecentGames(pl.getGames());//rg stands for recent games.
		sb.append("\t     ").append("5 MOST RECENT GAMES").append("\n\n");

		for (int i = 0; i<=5; i++) {
			if (pl.gamesPlayed>= 0) {
				if (rg[i]!=null) 
					sb.append(rg[i].toString()).append("\n");
			}
		}
		return sb.toString();
	}
	
	public void setTextGames(String name) {
		txtAreaGames.setText(getRecentGames(name));
	}
}
