package view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;

import javax.swing.JFrame;

import controller.GameController;

public class MainWindow extends JFrame{
	public final static int WIDTH = 1200;
	public final static int HEIGHT = 800;		
	public final static int TOP_HEIGHT = 80;
	public final static int PLAYER_WIDTH = 300;
	
	TopPanel topPnl;
	PlayerPanel leftPnl, rightPnl;
	MainAreaPanel mainPanel;
	GameController gc;
	
	public MainWindow(GameController gc) {
		super("TucTacToe");
		this.gc = gc;
		Container c = getContentPane();
		c.setPreferredSize(new Dimension(WIDTH, HEIGHT));
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		
		//top panel instance in main window
		this.topPnl = new TopPanel(gc);
		c.add(topPnl, BorderLayout.PAGE_START);
		
		//player panel instances in main window
		//left panel
		this.leftPnl = new PlayerPanel(gc, 0); //int indicates the position of the player
		c.add(leftPnl, BorderLayout.LINE_START);
		
		//right panel
		this.rightPnl = new PlayerPanel(gc, 1);
		c.add(rightPnl, BorderLayout.LINE_END);
		
		//adding main area panel
		this.mainPanel = new MainAreaPanel(gc);
		this.add(mainPanel, BorderLayout.CENTER);
		
		this.pack();	
	}

	public MainAreaPanel getMainPanel() {
		return mainPanel;
	}

	public  TopPanel getTopPanel() {
		return topPnl;
	}

	public PlayerPanel getLeftPnl() {
		return leftPnl;
	}

	public PlayerPanel getRightPnl() {
		return rightPnl;
	}

}
