package view;

import java.awt.*;
import controller.GameController;
import model.Player;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.text.AttributeSet.ColorAttribute;

public class TopPanel extends GamePanel{
	private JButton startGameBtn;
	private JButton doneBtn;
	private JButton addPlayerBtn;
	private JButton deletePlayerBtn;
	private JButton quitBtn;
	
	public TopPanel(GameController gc) {
		super(gc);
		this.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.setBorder(new LineBorder(Color.GRAY, 1));
		this.setPreferredSize(new Dimension(MainWindow.WIDTH, MainWindow.TOP_HEIGHT));
		this.setBackground(Color.RED);
		
		//view settings of the start game button 
		this.startGameBtn = new JButton("Start Game");
		this.startGameBtn.setPreferredSize(new Dimension(120, 40));
		this.startGameBtn.setEnabled(false);
		this.add(this.startGameBtn);
		this.startGameBtn.addActionListener((evt) ->{gc.startGame();});
		
		//view settings of the add player button
		this.addPlayerBtn = new JButton("Add player");
		this.addPlayerBtn.setPreferredSize(new Dimension(120, 40));
		this.addPlayerBtn.setEnabled(true);
		this.add(this.addPlayerBtn);
		this.addPlayerBtn.addActionListener((evt) -> {
			gc.getModel().getPlayerCatalogue().addPlayerInCatalogue(addPlayerBtnDialogue());
		});
		
		//view settings of the delete player button
		this.deletePlayerBtn = new JButton("Delete Player");
		this.deletePlayerBtn.setPreferredSize(new Dimension(140, 40));
		this.deletePlayerBtn.setEnabled(true);
		this.add(this.deletePlayerBtn);
		this.deletePlayerBtn.addActionListener(e -> {
			gc.getModel().getPlayerCatalogue().deletePlayer(deletePlayerBtnDialogue());
		});
		
		//view settings of the done button
		this.doneBtn = new JButton("Done");
		this.doneBtn.setPreferredSize(new Dimension(100, 40));
		this.doneBtn.setEnabled(false);
		this.add(this.doneBtn);
		
		//view settings of the quit button 
		this.quitBtn = new JButton("Quit");
		this.quitBtn.setPreferredSize(new Dimension(100, 40));
		this.quitBtn.addActionListener((evt)->{this.gc.quit();}); //action listener of the quit button
		this.add(this.quitBtn);
	}

	private String deletePlayerBtnDialogue() {
		String[] allPlayers = gc.getModel().getPlayerCatalogue().getPlayersObjNames();
		//Arrays.sort(allPlayers);

		String selPlayer = (String) JOptionPane.showInputDialog(this, 
				"Choose a Player...",
				"Player selection",
				JOptionPane.PLAIN_MESSAGE,
				null,
				allPlayers,
				null
				);
			this.repaint();
			return selPlayer;
	}


	private String addPlayerBtnDialogue() {
		String playerNameAdd = JOptionPane.showInputDialog("Give player name");
		return playerNameAdd;
	}

	public JButton getStartGameBtn() {
		return startGameBtn;
	}

	public JButton getDoneBtn() {
		return doneBtn;
	}

	public JButton getQuitBtn() {
		return quitBtn;
	}
	
	public JButton getDeletePlayerBtn() {
		return deletePlayerBtn;
	}

	public void changeColorInGame() {
		this.setBackground(Color.GREEN); //changes color of the top panel in green when in game
	}
	
	public void changeColorNoGame() {
		this.setBackground(Color.RED); //changes color of the top panel in red when no game is happening
	}
	
	public void doneBtnFunc() {
		this.doneBtn.addActionListener((evt) -> {
			this.setBackground(Color.RED);
			String player0 = gc.getModel().getGamePlayers()[0];
			String player1 = gc.getModel().getGamePlayers()[1];
			gc.getView().getMainPanel().showCard("hof");
			gc.getView().getLeftPnl().getSelectPlayerBtn().setEnabled(true);
		 	gc.getView().getRightPnl().getSelectPlayerBtn().setEnabled(true);
			this.startGameBtn.setEnabled(true);//model holds previous players so someone can start right away
			gc.getView().getLeftPnl().setPlayerStats(gc.getModel().getPlayerStats(player0));
			gc.getView().getRightPnl().setPlayerStats(gc.getModel().getPlayerStats(player1));
			this.getDeletePlayerBtn().setEnabled(true);
			gc.getView().getMainPanel().getHof().setTopFive(); //updates the hall of fame top players
		 	this.getDoneBtn().setEnabled(false);
			}
		);
	}

}
