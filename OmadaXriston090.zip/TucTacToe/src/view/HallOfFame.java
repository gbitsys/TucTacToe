package view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.GameController;
import model.GameRecord;
import model.Player;
import model.PlayersCatalogue;

public class HallOfFame extends GamePanel{
	JButton fiveRecentBtn, fiveTopBtn;
	JTextArea txtArea;
	
	
	public HallOfFame (GameController gc) {
		super(gc);
		
		this.fiveRecentBtn = new JButton("5 Recent Games");
		this.fiveRecentBtn.setPreferredSize(new Dimension(150,30));
		this.fiveRecentBtn.setEnabled(true);
		this.add(this.fiveRecentBtn);
		this.fiveRecentBtn.addActionListener(e->{
			Player pl = getModel().getPlayerCatalogue().getPlayerByName(choosePlayer());
			gc.getView().getMainPanel().getFiveRecent().setTextGames(pl.getName());
			gc.getView().getMainPanel().showCard("5r"); //5r stands for 5 recent
			
		});
		
		
		this.fiveTopBtn = new JButton("Top 5 Games");
		this.fiveTopBtn.setPreferredSize(new Dimension(150,30));
		this.fiveTopBtn.setEnabled(true);
		this.add(this.fiveTopBtn);
		this.fiveTopBtn.addActionListener(e->{
			Player pl = getModel().getPlayerCatalogue().getPlayerByName(choosePlayer());
			gc.getView().getMainPanel().getTopGames().setTextGames(pl.getName());
			gc.getView().getMainPanel().showCard("top5"); //top5 stands for top 5 games

		});
		
		txtArea = new JTextArea();		
		txtArea.setPreferredSize(new Dimension(MainWindow.WIDTH - 2 * MainWindow.PLAYER_WIDTH, MainWindow.HEIGHT - MainWindow.TOP_HEIGHT- 150));
		txtArea.setAlignmentX(CENTER_ALIGNMENT);
		Font statsf = new Font("SansSerif", Font.BOLD,20);
		txtArea.setFont(statsf);
		txtArea.setEnabled(false);		
		txtArea.setMargin(new Insets(10, 10, 10, 10));
		
		this.add(this.txtArea);
		
		this.txtArea.setText(getTopFivePlayers());
		
	}
	
	private String choosePlayer() {
		String[] allPlayers = gc.getModel().getPlayerCatalogue().getPlayersObjNames();
		//Arrays.sort(allPlayers);

		String selPlayer = (String) JOptionPane.showInputDialog(this, 
				"Choose a Player...",
				"Player selection",
				JOptionPane.PLAIN_MESSAGE,
				null,
				allPlayers,
				null
				);
			this.repaint();
			return selPlayer;
	}
	
	private String getPlayerGames(GameRecord[] gr) {
		String[] fiveGamesStr = new String[5];
		for (int i = 0; i < 5; i++) {
			if (gr[i]!=null) {
				fiveGamesStr[i]=gr[i].toString();
			}
		}
		return null;
	}
	
	public String getTopFivePlayers() {
		StringBuilder sb = new StringBuilder("");
		Player[] playersObjHere = PlayersCatalogue.hofSort();
		sb.append("\t     ").append("HALL OF FAME").append("\n\n");
		sb.append("1.").append("\t").append((playersObjHere)[0].getName()).append("\t"+playersObjHere[0].getScore()).append("\n");
		sb.append("2.").append("\t").append((playersObjHere)[1].getName()).append("\t"+playersObjHere[1].getScore()).append("\n");
		sb.append("3.").append("\t").append((playersObjHere)[2].getName()).append("\t"+playersObjHere[2].getScore()).append("\n");
		sb.append("4.").append("\t").append((playersObjHere)[3].getName()).append("\t"+playersObjHere[3].getScore()).append("\n");
		sb.append("5.").append("\t").append((playersObjHere)[4].getName()).append("\t"+playersObjHere[4].getScore()).append("\n");
		
		return sb.toString();			
	}
	
	public void setTopFive() {
		this.txtArea.setText(getTopFivePlayers());
	}
}
