package view;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JTextArea;

import controller.GameController;
import model.GameRecord;
import model.Player;

public class TopGames extends GamePanel{
	
	JTextArea txtAreaGames;
	JButton backBtn; //gets us to hall of fame
	String plName;

	public TopGames(GameController gc) {
		super(gc);
		backBtn = new JButton("Back");
		backBtn.setPreferredSize(new Dimension(100, 40));
		backBtn.setEnabled(true);
		this.add(backBtn);
		backBtn.addActionListener(e -> {
			gc.getView().getMainPanel().showCard("hof");
		});
		
		txtAreaGames = new JTextArea(10,10);		
		txtAreaGames.setPreferredSize(new Dimension(MainWindow.WIDTH - 2 * MainWindow.PLAYER_WIDTH, MainWindow.HEIGHT - MainWindow.TOP_HEIGHT));
		txtAreaGames.setAlignmentX(CENTER_ALIGNMENT);
		Font font = new Font("SansSerif", Font.BOLD,15);
		txtAreaGames.setFont(font);
		txtAreaGames.setEnabled(false);		
		txtAreaGames.setMargin(new Insets(10, 10, 10, 10));
		
		add(txtAreaGames);
		
		
	}

	public String getTop5Games(String name) {
		StringBuilder sb = new StringBuilder("");
		Player pl = getModel().getPlayerCatalogue().getPlayerByName(name);
		GameRecord[] gr = new GameRecord[5];
		gr = pl.findTopGames(pl.getGames());
		sb.append("\t     ").append("TOP 5 GAMES").append("\n\n");


		for (int i = 0; i < 5; i++) {
			if (gr[i]!=null) 
				sb.append((i+1) +". ").append(gr[i].toString()).append("\n");
		}
			return sb.toString();
		
	}
	
	public void setTextGames(String name) {
		txtAreaGames.setText(getTop5Games(name));
	}
}


