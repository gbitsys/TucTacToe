package app;
import controller.GameController;
//import control.GameController;
import view.MainWindow;

public class TucTacToe {

	public static void main(String[] args) {
		GameController gc = new GameController();
		gc.start();
	}
}