package model;



import java.io.Serializable;
import java.util.Date;

/**
 * A class which describes the finished games of each player. Saves: the opponent, the result, the players'
 * personal score and the time period of the game. The info of this class is personal for each player.
 * 
 * @author Thomas
 *
 */


public class GameRecord implements Serializable {
	
	private Player opponent;
	//result=-1 -> opponent won. result=0 -> tie. result=1 -> player who reference to this instance (this) won.
	private int result;
	//scores of each player. It's final because it doesn't change through time.
	private double opponentScore, playerScore;
	//date of the day the game played.
	private Date dateTime;
	
	/*Constructor initializes all to null or unrelated values because all will be set after a game ends.*/
	public GameRecord() {
		this.opponent = new Player("null");
		this.result = 10;
		this.opponentScore = 0;
		this.playerScore = 0;
		this.dateTime = new Date();
	}
		
	
	public Player getOpponent() {
		return opponent;
	}

	public int getResult() {
		return result;
	}

	public double getOpponentScore() {
		return opponentScore;
	}

	public double getPlayerScore() {
		return playerScore;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setOpponent(Player opponent) {
		this.opponent = opponent;
	}

	public void setResult(int result) {
		this.result = result;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}


	public void setOpponentScore(double opponentScore) {
		this.opponentScore = opponentScore;
	}


	public void setPlayerScore(double playerScore) {
		this.playerScore = playerScore;
	}

	@Override
	public String toString() {
		String resultCase=null;
		if (result == 1) 
			resultCase = "Won";
		if (result == 0)
			resultCase = "Tie";
		if (result == -1)
			resultCase = "Lost";
		return ("Against: "+this.opponent.getName()+" ,Date: "+this.dateTime+", Result: "+resultCase);
	}
	
	
}	
