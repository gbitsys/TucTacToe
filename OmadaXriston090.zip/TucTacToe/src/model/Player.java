package model;

import java.io.Serializable;
import java.util.Date;


//the actual class of player where we can store statistics of them
public class Player implements Serializable{
	protected String name;
	protected boolean ai;
	public int gamesPlayed;
	protected GameRecord[] games;
	protected double winPercentage;
	protected double losePercentage;
	protected int gamesWinned;
	protected int gamesLosed;
	protected int gamesTied;
	protected double score;
	
	public Player(String name) {
		this.games = new GameRecord[500];
		this.name = name;
		this.ai = false;
		this.gamesPlayed = 0;
		this.winPercentage = 0;
		this.losePercentage = 0;
		this.gamesWinned = 0;
		this.gamesLosed = 0;
		this.gamesTied = 0;
		this.score = 0;
	}


	public GameRecord[] getGames() {
		return games;
	}


	//getters
	public String getName() {
		return name;
	}

	public double getWinPercentage() {
		if (gamesPlayed != 0)
			return (gamesWinned*100/gamesPlayed);
		return 0;
	}

	public double getLosePercentage() {
		if (gamesPlayed != 0)
			return (gamesLosed*100/gamesPlayed);
		return 0;
	}

	public int getGamesWinned() {
		return gamesWinned;
	}

	public int getGamesLosed() {
		return gamesLosed;
	}

	public double getScore() {
		if (this.gamesPlayed != 0)
			return 50*((2*gamesWinned)+gamesTied)/(gamesPlayed);
		return 0;
	}
	
	public boolean isAi() {
		return ai;
	}
		
	public int getGamesTied() {
		return gamesTied;
	}
	
	//setters
	public void setAi(boolean ai) {
		this.ai = ai;
	}
	
	public void setName(String name) {
		this.name = name;
	}

	public void setWinPercentage(double winPercentage) {
		this.winPercentage = winPercentage;
	}

	public void setLosePercentage(double losePercentage) {
		this.losePercentage = losePercentage;
	}

	public void setGamesWinned(int gamesWinned) {
		this.gamesWinned = gamesWinned;
	}

	public void setGamesLosed(int gamesLosed) {
		this.gamesLosed = gamesLosed;
	}

	public void setScore(double score) {
		this.score = score;
	}
	
	public void setGamesTied(int gameTied) {
		this.gamesTied = gameTied;
	}
	
	public void incrementGamesPlayed() {
		this.gamesPlayed++;
	}
	
	public void incrementWinOne() {
		this.gamesWinned++;
		System.out.println("[DEBUG]Player :"+this.name+" winned a game num of Wins: "+this.gamesWinned);
	}
	
	public void incrementLoseOne() {
		this.gamesLosed++;
		System.out.println("[DEBUG]Player :"+this.name+" losed a game num of Loses: "+this.gamesLosed);
	}
	
	public void incrementTieOne() {
		this.gamesTied++;
		System.out.println("[DEBUG]Tie "+this.gamesTied+" name: "+this.name);
	}
	
	public void updateScore() {
		
	}
	
	
	public GameRecord[] findRecentGames(GameRecord[] gameRecord) {
		GameRecord[] arr = gameRecord;
		boolean swapped = true;
		
		while(swapped) {
			swapped = false;
			for(int i=1;i<gamesPlayed;i++) {
				if(arr[i]!= null) {
					if(arr[i].getDateTime().after(arr[i-1].getDateTime())) {
						swapped = true;
						GameRecord temp = arr[i-1];
						arr[i-1] = arr[i];
						arr[i] = temp;
					}
				}
			}
		}
		return arr;
	}
	
	
	/*This method (it's a selection sort algo) returns the top n games based on the following criteria (the 1st is more important than the 2nd etc...).
	 * 
	 * 1) The result of the game (win>draw>loss)
	 * 2) If the result of two games is the same compare the score of the opponent on the time the game took place.
	 * 3) If both 1 and 2 are the same then the most recent game comes first.
	 * 
	 * Returns a sorted array.*/
	public GameRecord[] findTopGames(GameRecord[] gameRecord) {
		GameRecord[] arr = gameRecord;
		GameRecord temp = new GameRecord();
		boolean swapped = true;
		
		while(swapped) {
			swapped = false;
			for(int j=1; j<gamesPlayed; j++) {
				if(arr[j] != null) {
					System.out.println("[DEBUG]findTopGames entered if i:" +(j+1));
					if(arr[j-1].getResult() < arr[j].getResult()) {
						swapped = true;
						System.out.println("[DEBUG]findTopGames entered if number 1" );
						temp = arr[j-1];
						arr[j-1] = arr[j];
						arr[j] = temp;
						continue;
						}
					else if(arr[j-1].getResult() == arr[j].getResult() && arr[j-1].getOpponentScore() < arr[j].getOpponentScore()) {
						swapped = true;
						System.out.println("[DEBUG]findTopGames entered if number 2" );
						temp = arr[j-1];
						arr[j-1] = arr[j];
						arr[j] = temp;
						continue;
						}
					else if(arr[j-1].getResult() == arr[j].getResult() && arr[j-1].getOpponentScore() == arr[j].getOpponentScore() &&  arr[j].getDateTime().after(arr[j-1].getDateTime())) {
						swapped = true;
						System.out.println("[DEBUG]findTopGames entered if number 3" );
						temp = arr[j-1];
						arr[j-1] = arr[j];
						arr[j] = temp;	
						continue;
						}
						
				}
			}
		}
		for(int i=0; i<25; i++) {
			if(arr[i] != null)
				System.out.println("[DEBUG]findTopGames  "+arr[i].getOpponent().getName() + "  " + arr[i].getResult());
			else if(arr[i] == null)
				System.out.println("null");
		}
		return arr;
	}
	

	public void addGameRecord(Player opponent, int result, double opponentScore, double playerScore, Date dateTime) {
		if(games[gamesPlayed] == null) {	
			games[gamesPlayed] = new GameRecord();
			games[gamesPlayed].setDateTime(dateTime);
			games[gamesPlayed].setOpponent(opponent);
			games[gamesPlayed].setResult(result);
			games[gamesPlayed].setOpponentScore(opponentScore);
			games[gamesPlayed].setPlayerScore(playerScore);
			gamesPlayed++;
			System.out.println("[DEBUG]Games Played: " + gamesPlayed);
		}
	}

}
