package model;


import java.util.Date;
import java.util.concurrent.TimeUnit;

import controller.GameController;
import util.RandomPlay;
import util.Minimax;
import util.Minimax.Move;

public class GameModel {
	private PlayersCatalogue  playerCatalogue;
	private String [] gamePlayers;		
	private Player[] playersObj;
	private char[][] gameBoard;
	private String[] line;
	private GameController gc;
	private Boolean mover;
	private Boolean flagPlay;
	private Boolean flagTie;
	
	public Boolean getFlagPlay() {
		return flagPlay;
	}

	public void setFlagPlay(Boolean flagPlay) {
		this.flagPlay = flagPlay;
	}

	private int[] lastPoint; //last move played. lastPoint[0] -> row and lastPoint[1] -> col.
	
	
	/*
	String line1 = gameBoard[0][0] + gameBoard[0][1] + gameBoard[0][2] ; // ---
	String line1 = gameBoard[1][0] + gameBoard[1][1] + gameBoard[1][2] ; // ---
	String line2 = gameBoard[2][0] + gameBoard[2][1] + gameBoard[2][2] ; // ---
	String line3 = gameBoard[0][0] + gameBoard[1][0] + gameBoard[2][0] ; // |
	String line4 = gameBoard[0][1] + gameBoard[1][1] + gameBoard[2][1] ; // |
	String line5 = gameBoard[0][2] + gameBoard[1][2] + gameBoard[2][2] ; // |
	String line6 = gameBoard[0][0] + gameBoard[1][1] + gameBoard[2][2] ; // \
	String line7 = gameBoard[0][2] + gameBoard[1][1]+ gameBoard[0][2]  ; // /
	*/
	/*player 0 = "X" left
	 * player 1 = "O" right
	 * 
	 */
	
	public GameModel(GameController gc) {
		this.gc=gc;
		this.line = new String[8]; //to check combinations
		this.gamePlayers = new String[2];
		this.playersObj = new Player[2];
		gameBoard = null;
		playerCatalogue = new PlayersCatalogue(gc);
		mover = false;
		this.flagTie=false;
		lastPoint = new int[2];
	}
	
	private void gameAI() {
			if(inPlay()) {
				System.out.println("[DEBUG] Entered gameAI");
				if (playersObj[0].isAi() && !playersObj[1].isAi() && mover) {
					makeMoveAI(playersObj[0]);
				}
				else if (playersObj[1].isAi() && !playersObj[0].isAi() && !mover) {
					makeMoveAI(playersObj[1]);
				}
					
				else if (playersObj[1].isAi() && playersObj[0].isAi()) {
					
					
					if(mover) 
						makeMoveAI(playersObj[0]);
					else if(!mover) 
						makeMoveAI(playersObj[1]);
				}
				else 
					return;
			
			}
		
	}
	
	public void checkDimValidity(int row, int col) {
		if (row <0 || col < 0 || row > 2 || col >2) {
			throw new IndexOutOfBoundsException(row + ","+col +" is not a valid board cell"); //checks if the dimension of the board is right
		}
	}
	
	//checks if a move can be made (validity) if it isn't throws an exception  
	public void checkMoveValidity(int row, int col) {
		checkDimValidity(row, col);
		if (gameBoard[row][col] !=' ' || checkWin()) {
			throw new IllegalArgumentException("Non playable cell"); //if the cell has already been played throws an exception
		}
	}
	
	public boolean checkIfFull() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				if (gameBoard[i][j]==' ') {
					return false;
				}
			}
		}
		return true;
	}

	public boolean checkWin () {
		for (int i = 0; i < 8; i ++) {
			
			//if line is null (or blank) we go outside of the loop
		 	if (checkIfLineNull(i)) {
		 		System.out.println("[DEBUG] line null");
		 		return false;
		 	}
		 	
			if (this.line[i].equals("XXX") || this.line[i].equals("OOO")) {
				return true;
			}
		}
		return false;
	}
	
	//get winner loser or tie and set the game record for each player.
	public int getPlayersResult() {
		for (int i = 0; i < 8; i++) {
			if (checkWin() && line[i].equals("XXX")) { //left player 
				setPlayerWinLose(playersObj[0], playersObj[1]);
				System.out.println(playersObj[0].gamesPlayed);
				playersObj[0].addGameRecord(playersObj[1], 1, playersObj[0].getScore(), playersObj[1].getScore(), new Date());
				playersObj[1].addGameRecord(playersObj[0], -1, playersObj[1].getScore(), playersObj[0].getScore(), new Date());
				//incrementGamesPlayed();
				return 0;
			}
			if (checkWin() && line[i].equals("OOO")) {
				setPlayerWinLose(playersObj[1], playersObj[0]);
				playersObj[0].addGameRecord(playersObj[1], -1, playersObj[0].getScore(), playersObj[1].getScore(), new Date());
				playersObj[1].addGameRecord(playersObj[0], 1, playersObj[1].getScore(), playersObj[0].getScore(), new Date());	
				//incrementGamesPlayed();
				return 1;
			}
			if (checkIfFull() && !checkWin()) {
				this.flagTie=true;
				setPlayersTie();
				playersObj[0].addGameRecord(playersObj[1], 0, playersObj[0].getScore(), playersObj[1].getScore(), new Date());
				playersObj[1].addGameRecord(playersObj[0], 0, playersObj[1].getScore(), playersObj[0].getScore(), new Date());
				//incrementGamesPlayed();
				return -1;
			}
		}
		return 2;//if an error happens we can handle it with this value
	}
	
	//this method record a win on an object of player
	public void setPlayerWinLose(Player playerW, Player playerL) {
		playerW.incrementWinOne();
		playerL.incrementLoseOne();
	}
	
	//checks if a line has characters in it 
	private boolean checkIfLineNull(int i) {
		if (line[i]==null) 
			return true;
		
		return false;
	}

	//to take a single cell
	public char getBoardMark(int row, int col) {
		checkDimValidity(row, col);
		return gameBoard[row][col];
	}
	
	public void makeMove(int row, int col) {
		checkMoveValidity(row, col); 
		gameBoard[row][col]=getMoverMark();
		updateLines();
		System.out.println("[DEBUG] gameBoard elem: "+this.gameBoard[row][col]); //just to see the mark that was played
		System.out.println("[DEBUG] line 0: "+this.line[0]);
		mover=!mover;
		
		gameAI();
	}
	
	
	public void makeMoveAI(Player player) {
		Move move = null;
		System.out.println("[DEBUG]Entered makeMoveAI");
		
		/*Here checks if the player is Mr.Bean or Hal  because in the app we dont have the option of 
		 * creating an AI player.*/
		if (player.equals(playerCatalogue.getPlayerByName("Mr.Bean"))) {
			move = RandomPlay.randomMove(gameBoard);
			gc.getView().getMainPanel().getBoard().getCells()[move.row][move.col].makeMoveAI();
		}
		else if (player.equals(playerCatalogue.getPlayerByName("Hal"))) {
			move = Minimax.findBestMove(getCurrentBoard(), isMoverX());
			gc.getView().getMainPanel().getBoard().getCells()[move.row][move.col].makeMoveAI();
		}

		
		
	}
	
	public char getMoverMark() {
		return mover? 'X': 'O'; //if true "X", if false "O"
	}
	
	public boolean isMoverX() {
		if (getMoverMark() == 'X')
			return true;
		else 
			return false;
	}
	
	public void selectPlayer(String player, int pos) {
		if (pos<0 && pos>1)return;
		
		gamePlayers[pos]=player;	//sets the position of the players
		playersObj[pos]=gc.getModel().getPlayerCatalogue().getPlayerByName(gamePlayers[pos]);
		System.out.println("[DEBUG] player obj :"+playersObj[pos]+" pos: "+pos);
	}
	
	public boolean ready() {
		return (gamePlayers[0] != null && gamePlayers[1] !=null);
	}
		
	public void startGame() {
		//initializing and clear data
		gameBoard= new char[3][3];
		mover = true;
		setGameBoard();
		updateLines();
		setFlagPlay(true);
		gameAI();
	}
	
	public void updateLines() {
		//updating lines to the array after the game board is initialized
		line[0] = Character.toString(gameBoard[0][0]) + Character.toString(gameBoard[0][1]) + Character.toString(gameBoard[0][2]) ; // ---
		line[1] = Character.toString(gameBoard[1][0]) + Character.toString(gameBoard[1][1]) + Character.toString(gameBoard[1][2]) ; // ---
		line[2] = Character.toString(gameBoard[2][0]) + Character.toString(gameBoard[2][1]) + Character.toString(gameBoard[2][2]) ; // ---
		line[3] = Character.toString(gameBoard[0][0]) + Character.toString(gameBoard[1][0]) + Character.toString(gameBoard[2][0]) ; // |
		line[4] = Character.toString(gameBoard[0][1]) + Character.toString(gameBoard[1][1]) + Character.toString(gameBoard[2][1]) ; // |
		line[5] = Character.toString(gameBoard[0][2]) + Character.toString(gameBoard[1][2]) + Character.toString(gameBoard[2][2]) ; // |
		line[6] = Character.toString(gameBoard[0][0]) + Character.toString(gameBoard[1][1]) + Character.toString(gameBoard[2][2]) ; // \
		line[7] = Character.toString(gameBoard[2][0]) + Character.toString(gameBoard[1][1]) + Character.toString(gameBoard[0][2])  ;// /
		
		if (checkWin()) 
			gc.winCase();
		
		if (checkIfFull() && !checkWin())	
			gc.fullCase();
	}
	
	/*
	 * inPlay and noPlay methods are used in game controller for choose player buttons,
	 * to be enabled or disabled according to the state of the main area panel (hof or gb or resPnlbv)
	 */
	
	public boolean inPlay() {
		gc.inPlay();
		return flagPlay;
	}
	
	public boolean noPlay() {
		gc.noPlay();
		return !inPlay();
	}
	
	public String[] getGamePlayers() {
		return gamePlayers;
	}

	public char[][] getGameBoard() {
		return gameBoard;
	}

	public PlayersCatalogue getPlayerCatalogue() {
		return playerCatalogue;
	}

	public void setPlayerCatalogue(PlayersCatalogue playerCatalogue) {
		this.playerCatalogue = playerCatalogue;
	}
	
	public String getPlayerStats(String player) {
		StringBuilder sb = new StringBuilder("");
		Player playerObj = gc.getModel().getPlayerCatalogue().getPlayerByName(player);
		sb.append(player).append("\n\n\n");
		sb.append("Total:").append("\t").append(playerObj.gamesPlayed).append("\n");
		sb.append("Won:").append("\t").append(playerObj.getWinPercentage()).append("%").append("\n");
		sb.append("Lost:").append("\t").append(playerObj.getLosePercentage()).append("%").append("\n");
		sb.append("Score: ").append("\t").append(playerObj.getScore()).append("\n");
		return sb.toString();			
	}
	
	//if we don't do this we will have logical errors null related
	public void setGameBoard() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++ ){
				this.gameBoard[i][j] = ' ';
				System.out.println("[DEBUG]cell set with coords ("+i+", "+j+")"+gameBoard[i][j]);
			}
		}
	}

	//[0] = row [1] = column
	public int[] getLastPoint() {
		return lastPoint;
	}
	
	public Player[] getPlayersObj() {
		return playersObj;
	}

	public int getLastRow() {
		return lastPoint[0];
	}
	
	public int getLastCol() {
		return lastPoint[1];
	}

	public void setLastPoint(int[] lastPoint) {
		this.lastPoint = lastPoint;
	}

	public void setGamePlayers(String[] gamePlayers) {
		this.gamePlayers = gamePlayers;
	}
	
	//gets the winner player
	public Player getPlayerWinner() {
		
		if (getPlayersResult() == 0)
			return playersObj[0];
		if (getPlayersResult() == 1)
			return playersObj[1];
					
		return null; //if game is tie or an error happens
		
	}
	
	public Player getPlayerLoser() {
		
		if (getPlayersResult() == 0)
			return playersObj[1];
		if (getPlayersResult() == 1)
			return playersObj[0];
					
		return null; //if game is tie or an error happens
	}
	
	private void setPlayersTie() {
			playersObj[0].incrementTieOne();
			playersObj[1].incrementTieOne();
	}
	
	private void incrementGamesPlayed() {
		playersObj[0].incrementGamesPlayed();
		playersObj[1].incrementGamesPlayed();
	}

	public char[][] getCurrentBoard() {
		return gameBoard;
	}
}
