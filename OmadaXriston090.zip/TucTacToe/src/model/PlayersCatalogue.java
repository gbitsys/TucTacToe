package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import controller.GameController;

//used to get players from our back-end source

public class PlayersCatalogue implements Serializable {
	GameController gc;
	String[] players; //names of the players
	String[] gamePlayers;
	public static  Player[] playersObj;
	private static  int numOfPlayers;
	private static final int maxNumOfPlayers = 50;
	
	public PlayersCatalogue(GameController gc) {
		playersObj = new Player[maxNumOfPlayers];
		this.gc = gc;
		loadPlayers();
		//playersObj[0] = new Player("Giorgos");
		//playersObj[1] = new Player("Thanasis"); 
		//playersObj[2] = new Player("Thomas"); 
		//playersObj[3] = new Player("Nikolas"); 
		//playersObj[4] = new Player("Hal");
		//playersObj[4].setAi(true); 
		//playersObj[5] = new Player("Mr.Bean");
		//playersObj[5].setAi(true);
		
		numOfPlayers =5;
		 
	}
	
	
	public Player[] getPlayersObj() {
		return playersObj;
	}

	public void setPlayersObj(Player[] playersObj) {
		this.playersObj = playersObj;
	}

	public String getPlayer(int i) {
		if (i < 0 || i > maxNumOfPlayers) return null;
		return players[i];
	}

	//these players appear in the dialog of choose player button
	public String[] getPlayers() {
		return players;
	}

	public String getPlayerStats(String currentPlayer) {
		return null;
	}

	public String[] getPlayersObjNames() {
		String[] names = new String[maxNumOfPlayers];
		for (int i = 0; i < maxNumOfPlayers; i++) {
			if (playersObj[i]!=null) {
				names[i] = playersObj[i].getName();
			}
		}
		return names;
	}
	
	public Player getPlayerByName(String name) {
		for(int i = 0; i < maxNumOfPlayers; i++) {
			if (playersObj[i]!=null && playersObj[i].getName().equals(name))
				return playersObj[i];
		}
		return null;
	}
	
	//used to check if a name already exists, if it already exists returns false
	public boolean validCheckName(String name) {
		for (int i = 0; i < maxNumOfPlayers; i++) {
			if (playersObj[i] != null && playersObj[i].getName().equals(name)) {
				return false;
			}
		}
		return true;
	}
	
	public void addPlayerInCatalogue(String name) {
		if (name.length() > 20) {
			gc.getView().getMainPanel().showNameError(0);
			return;
		}
		for (int i = 0; i < maxNumOfPlayers; i++) {
			if (playersObj[i] == null && validCheckName(name)) {//if a slot is null you can add the player
				playersObj[i] = new Player(name);
				System.out.println("[DEBUG] player added with name: "+name+" Object: "+ playersObj[i]);
				numOfPlayers++;
				return; 
			}
		}
		gc.getView().getMainPanel().showNameError(1);
	}

	
	/*This method is to store players to a file tuctactoe.ser. It is called every time the app closes.*/
	
	public static void storePlayers() {
		ObjectOutputStream os = null;
		FileOutputStream fos = null;
		File file = null; 
		
		try {
			file = new File("resource\\tuctactoe.ser");
			file.delete();
			
			fos = new FileOutputStream("resource\\tuctactoe.ser");
			os = new ObjectOutputStream(fos);
			

			
			for(Player player: playersObj) {
				os.writeObject(player);
			}
			System.out.println("All players stored succesfully...");
		}catch(FileNotFoundException e) {
			System.out.println(e.getMessage());
		}catch(IOException e) {
			System.out.println("IOException");
			e.printStackTrace();
		}finally {
			try {
				os.close();
				fos.close();
			}catch(Exception e) {
				System.out.println("Problem on closing file...");
			};
		}
	}
	
	
	/*This method is to load the players from the resource file.*/
	public static void loadPlayers() {
		ObjectInputStream ois = null;
		FileInputStream fis = null;
		
		int pos = 0;
	
	try {
		fis = new FileInputStream("resource\\tuctactoe.ser");
		ois = new ObjectInputStream(fis);
				
		while(fis.available()>0) {
			Player player = (Player)ois.readObject();
			playersObj[pos] = player;
			//System.out.println("Loaded player: " + playersObj[pos].getName());
			pos++;
			numOfPlayers++;
		}
		
		System.out.println("Loaded " + playersObj.length + " players.");
		System.out.println("---------------------------------------------------------");
	}catch(FileNotFoundException e) {
		System.out.println(e.getMessage());
	}catch(IOException e) {
		e.printStackTrace();
	}catch(ClassNotFoundException e) {
		System.out.println("Class not found for read objects...");
	}finally {
		try {
			ois.close();
			fis.close();
		}catch(Exception e) {
			System.out.println("Problem on closing file...");
		}
	}
	}
	
	/*This method sorts the array of PlayersObj based on the score of each player and returns the sorted array.
	 * It's the bubble sort algorithm.*/
	public static  Player[] hofSort() {
		boolean swapped;
		Player[] arr = new Player[maxNumOfPlayers]; 
		arr = playersObj;
		
		swapped = true;
		while(swapped) {
			swapped = false;
			for(int i=0; i< numOfPlayers; i++) {
				//If the score of player i is < of the score of player i+1 then swap them.
				if(arr[i].getScore()<arr[i+1].getScore()) {
					swapped = true;
					Player temp = arr[i];
					arr[i] = arr[i+1];
					arr[i+1] = temp;
				}
			}
		}
		return arr;
	}
	
	public void deletePlayer(String name) {
		for (int i = 0; i < numOfPlayers; i++) {
			if (playersObj[i] != null && playersObj[i].getName().equals(name)) {
				playersObj[i]=null;
				for (int j = i; j < maxNumOfPlayers - i - 1; j ++) {
					playersObj[j]=playersObj[j+1];
				}
				playersObj[maxNumOfPlayers-1]=null;
				numOfPlayers--;
			}
		}
	}
}