package util;

import java.util.Random;

import util.Minimax.Move;

/**
 * This class has all the methods for the ai player which plays random moves.
 * 
 * @author Thomas
 *
 */
public class RandomPlay {
	
	char[][] board;
	
	public static Move randomMove(char[][] board) {
		Move move = new Move();
		Random random = new Random();
		boolean flag;

		
		do {
			System.out.println("[DEBUG]loop check");
			flag = false;
			move.row = random.nextInt(3);
			move.col = random.nextInt(3);
			if (board[move.row][move.col] != ' ')
				flag = true;
		}while(flag);

		return move;
	}

}
