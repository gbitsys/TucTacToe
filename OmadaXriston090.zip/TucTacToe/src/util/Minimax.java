package util;

/**
 * This is the minimax algorithm used for the AI player.
 * 
 * @author Thomas
 *
 */
public class Minimax {
	
	public static class Move{
		public int row, col;
	}
	
	
	
	/*This method evaluates the current board and returns +1 if X wins -1 if O wins, else 0.*/
	public static int evaluate(char[][] gameBoard) {
		String line[] = {" ", " ", " ", " ", " ", " ", " ", " ",};
		/* The game can end in 8 different ways. This loop checks each one. */
		line[0] = Character.toString(gameBoard[0][0]) + Character.toString(gameBoard[0][1]) + Character.toString(gameBoard[0][2]) ; // ---
		line[1] = Character.toString(gameBoard[1][0]) + Character.toString(gameBoard[1][1]) + Character.toString(gameBoard[1][2]) ; // ---
		line[2] = Character.toString(gameBoard[2][0]) + Character.toString(gameBoard[2][1]) + Character.toString(gameBoard[2][2]) ; // ---
		line[3] = Character.toString(gameBoard[0][0]) + Character.toString(gameBoard[1][0]) + Character.toString(gameBoard[2][0]) ; // |
		line[4] = Character.toString(gameBoard[0][1]) + Character.toString(gameBoard[1][1]) + Character.toString(gameBoard[2][1]) ; // |
		line[5] = Character.toString(gameBoard[0][2]) + Character.toString(gameBoard[1][2]) + Character.toString(gameBoard[2][2]) ; // |
		line[6] = Character.toString(gameBoard[0][0]) + Character.toString(gameBoard[1][1]) + Character.toString(gameBoard[2][2]) ; // \
		line[7] = Character.toString(gameBoard[2][0]) + Character.toString(gameBoard[1][1]) + Character.toString(gameBoard[0][2])  ;// /
			
		for(int i=0;i<8;i++) {
			if(line[i].equals("XXX"))
				return 1;
			else if(line[i].equals("OOO"))
				return -1;
		}
		return 0;
	}
	
	public static int minimax(char[][] gameBoard, int depth, boolean isMax) {
		//System.out.println(gameBoard[0][0] + " " + gameBoard[0][1] + " " + gameBoard[0][2]);
		//System.out.println(gameBoard[1][0] + " " + gameBoard[1][1] + " " + gameBoard[1][2]);
		//System.out.println(gameBoard[2][0] + " " + gameBoard[2][1] + " " + gameBoard[2][2]);
		
		int score = evaluate(gameBoard);
		//System.out.println("Evaluation of current board: " + score);
		//System.out.println();
		
		
		/*return 1 if maximizer(X) has won*/
		if (score == 1)
			return 1;
		/*return -1 if minimizer(O) has won*/
		if (score == -1)
			return -1;
		/*return 0 if tie. If the depth is 9 then all the sells are nonEmpty.*/
		if (checkIfBoardIsFull(gameBoard))
			return 0;
		
		/*if it's maximizer's turn. We assume maximizer is X and minimizer is O.*/
		if (isMax) {
			int bestVal = -1000;
			
			/*Go to all cells*/
			for(int j=0;j<3;j++) {
			for(int i=0; i<3;i++) {
				if (gameBoard[j][i]== ' ') {
					
					gameBoard[j][i] = 'X';//make the move.
					
					/*Call minimax recursively and keep the maximum value.*/
					int currentVal = minimax(gameBoard, depth+1, !isMax);
					if (currentVal>bestVal) 
						bestVal = currentVal;
					
					gameBoard[j][i] = ' ';//Undo the move.
				}
			}
			}
			return bestVal;
		}
		
		//if it's minimizer's turn.
		else{
			int bestVal = 1000;
			
			/*Go to all sells*/
			for(int j=0;j<3;j++) {
			for(int i=0; i<3;i++) {
				if (gameBoard[j][i]== ' ') {
					
					gameBoard[j][i] = 'O';//make the move.
					
					/*Call minimax recursively and keep the minimum value.*/
					int currentVal = minimax(gameBoard, depth+1, !isMax);
					if (currentVal<bestVal) 
						bestVal = currentVal;
					
					
					gameBoard[j][i] = ' ';//Undo the move.
				}
			}
			}
			return bestVal;
		}

	}
	/*This method finds the best move.*/
	public static Move findBestMove(char[][] gameBoard, boolean isMax) {
		Move bestMove = new Move();
		
		
		//System.out.println(gameBoard[0][0] + " " + gameBoard[0][1] + " " + gameBoard[0][2]);
		//System.out.println(gameBoard[1][0] + " " + gameBoard[1][1] + " " + gameBoard[1][2]);
		//System.out.println(gameBoard[2][0] + " " + gameBoard[2][1] + " " + gameBoard[2][2]);
		//System.out.println("-------------------------------------------------------------------------");

		
		
		
		/*if it's maximizer's turn. We assume maximizer is X and minimizer is O.*/
		if (isMax) {
			int bestVal = -1000;
			
			
			
			
			
			/*Go to all sells*/
			for(int j=0;j<3;j++) {
			for(int i=0; i<3;i++) {
				if (gameBoard[j][i]==' ') {
					
					gameBoard[j][i] = 'X';//make the move.
					
					//System.out.println(gameBoard[0][0] + " " + gameBoard[0][1] + " " + gameBoard[0][2]);
					//System.out.println(gameBoard[1][0] + " " + gameBoard[1][1] + " " + gameBoard[1][2]);
					//System.out.println(gameBoard[2][0] + " " + gameBoard[2][1] + " " + gameBoard[2][2]);
					//System.out.println("Valuation of current board: " + evaluate(gameBoard));
					
					/*Call minimax recursively and keep the maximum value and the cell.*/
					int currentVal = minimax(gameBoard, 0, !isMax);
					//System.out.println("Current Valuation of the move: " + currentVal);
					//System.out.println(" ");
					if (currentVal>bestVal) {
						bestVal = currentVal;
						bestMove.row = j;
						bestMove.col = i;
					}
					gameBoard[j][i] = ' ';//Undo the move.
				}
			}
			}
			//System.out.println("Best Move: "+ bestMove.row + "," + bestMove.col);
			return bestMove;
		}
		
		//if it's minimizer's turn.
		else{
			int bestVal = 1000;
			
			/*Go to all sells*/
			for(int j=0;j<3;j++) {
			for(int i=0; i<3;i++) {
				if (gameBoard[j][i]==' ') {
					
					gameBoard[j][i] = 'O';//make the move.
					
					/*Call minimax recursively and keep the minimum value and the cell.*/
					int currentVal = minimax(gameBoard, 0, !isMax);
					if (currentVal<bestVal) {
						bestVal = currentVal;
						bestMove.row = j;
						bestMove.col = i;
					}
					
					gameBoard[j][i] = ' ';//Undo the move.
				}
			}
			}
			System.out.println("Best Move: "+ bestMove.row + "," + bestMove.col);
			return bestMove;
		}
		
	}
	/*This method checks if the board is full and returns true if it is.*/
	public static boolean checkIfBoardIsFull(char[][] gameBoard) {
		for (int j=0; j<3; j++) {
			for(int i=0; i<3; i++) {
				if (gameBoard[j][i] == ' ')
					return false;
			}
		}
		return true;
	}


}
