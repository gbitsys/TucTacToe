package util;

import model.GameRecord;

public class MyArrayList <T>{

	Object[] arr = new Object[5];
	int size = 0;
	
	
	public void add(Object el) {
		arr[size] = el;
		size++;
		if(size == arr.length) {
			Object[] newArr = new Object[size + 5];
			for(int i=0; i<size;i++) {
				newArr[i] = arr[i];
			}
			arr = newArr;
		}
	}

	
	public T get(int elementIndex) {
		return (T)arr[elementIndex];
	}

}
